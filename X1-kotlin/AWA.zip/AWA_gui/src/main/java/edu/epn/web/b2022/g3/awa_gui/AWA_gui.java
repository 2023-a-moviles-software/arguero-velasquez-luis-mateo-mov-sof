/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package edu.epn.web.b2022.g3.awa_gui;

/**
 *
 * @author luism
 */
public class AWA_gui {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
